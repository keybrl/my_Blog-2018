// first_example.c
#include <stdio.h>

int main()
{
    int n = 0, i;
    char ch, str[1000];

    printf("Please input your string: ");
    while ((ch = getchar()) != '\n')
        str[n++] = ch;

    printf("Your string in reverse order: ");
    for (i = 0;i < n;i++)
        printf("%c", str[n - i - 1]);
    printf("\n");
    return 0;
}
