# first_example.py
str = input('Please input your string: ')
print('Your string in reverse order:', str[::-1])
