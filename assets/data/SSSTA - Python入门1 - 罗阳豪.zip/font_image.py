# font_image.py
from PIL import Image

IMG = './new image - sthmn.jpg'
WIDTH = 200
HEIGHT = 75
OUTPUT = './font_image.txt'

gray_char = list("$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~<>i!lI;:,\"^`'. ")

def rgb_to_char(r, g, b, alpha = 1):
    gray = int((0.2126 * r + 0.7152 * g + 0.0722 * b) * alpha + (1 - alpha) * 255)
    unit = 256 / len(gray_char)
    return gray_char[int(gray / unit)]

im = Image.open(IMG)
im = im.resize((WIDTH,HEIGHT), Image.NEAREST)
txt = ""

for i in range(HEIGHT):
    for j in range(WIDTH):
        txt += rgb_to_char(*im.getpixel((j, i)))
    txt += '\n'
print(txt)

if OUTPUT:
    with open(OUTPUT, 'w') as f:
        f.write(txt)
else:
    with open("output.txt", 'w') as f:
        f.write(txt)
